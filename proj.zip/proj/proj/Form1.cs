﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proj
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Text = "노래 관리";

            label4.Text = DataManager.Songs.Count.ToString();
            label5.Text = DataManager.PlayLs.Count.ToString();
            label6.Text = DataManager.Songs.Where((x) => x.IsAdded).Count().ToString();
            dataGridView1.DataSource = DataManager.Songs;
        }

        private void ddfToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string address = "https://www.youtube.com/results?search_query=" + dataGridView1.CurrentRow.DataBoundItem;
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            string address = "https://www.youtube.com/results?search_query=";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string search;
            search = sender.ToString();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void webBrowser1_DocumentCompleted_1(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void dataGridView1_CurrentCellChanged(object sender, EventArgs e)
        {
            try
            {
                Song song = dataGridView1.CurrentRow.DataBoundItem as Song;
                textBox1.Text = song.Name.ToString();
            } catch (Exception ex)
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)  //플레이 리스트에 추가
        {
            try
            {
                Song song = DataManager.Songs.Single(x => x.Name == textBox1.Text);
                if (song.IsAdded)
                {
                    MessageBox.Show("이미 추가 되었습니다.");
                }
                else
                {
                    PlayL playL = DataManager.PlayLs.Single(x => x.Name == textBox2.Text);

                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = DataManager.Songs;
                    DataManager.Save();
                    MessageBox.Show(" 추가 되었습니다.");
                }
            }catch (Exception ex)
            {
                MessageBox.Show("???");
            }
      
    
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Song song = DataManager.Songs.Single(x => x.Name == textBox1.Text);
                if (song.IsAdded)
                {
                    PlayL playL = DataManager.PlayLs.Single(x => x.Id.ToString() == textBox2.Text);
                    song.UserName = "";
                    song.IsAdded = false;
                    song.AddedAt = new DateTime();

                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = DataManager.Songs;
                    DataManager.Save();
                }
                else
                {

                }
            }catch(Exception ex)
            {

            }
        }

        private void 노래목록ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form2().ShowDialog();
        }

        private void 플레이리스트ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form3.ShowDialog();
        }
    }
}
