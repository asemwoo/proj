﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace proj
{
    class DataManager
    {
        public static List<Song> Songs = new List<Song>();
        public static List<PlayL> PlayLs = new List<PlayL>();

        static DataManager()
        {
            Load();
        }
        public static void Load()
        {
            try
            {
                string songsOutput = File.ReadAllText(@"./Songs.xml");
                XElement songsXElement = XElement.Parse(songsOutput);
                Songs = (from item in songsXElement.Descendants("song")
                         select new Song()
                         {
                             Name = item.Element("name").Value,
                             AddedAt = DateTime.Parse(item.Element("addedAt").Value),
                             IsAdded = item.Element("isAdded").Value != "0" ? true : false,
                             UserId = int.Parse(item.Element("userId").Value),
                             UserName = item.Element("userName").Value
                         }).ToList<Song>();

                string usersOutput = File.ReadAllText(@"./Users.xml");
                XElement usersXElement = XElement.Parse(usersOutput);

                PlayLs = (from item in usersXElement.Descendants("user")
                         select new PlayL()
                         {
                             Id = int.Parse(item.Element("id").Value),
                             Name = item.Element("name").Value
                         }).ToList<PlayL>();
            }
            catch (FileNotFoundException exception)
            {
                Save();
            }
        }
        public static void Save()
        {
            string songsOutput = "";
            songsOutput += "<songs>\n";
            foreach (var item in Songs)
            {
                songsOutput += "<song>\n";
                songsOutput += "<name>\n" + item.Name + "</name>\n";
                songsOutput += "<addedAt>" + item.AddedAt.ToLongDateString() + "</addedAt>\n";
                songsOutput += "<isAdded>" + (item.IsAdded ? 1 : 0) + "</isAdded>\n";
                songsOutput += "<userid>" + item.UserId + "</userId>\n";
                songsOutput += "<userName>" + item.UserName + "</userName>\n";
                songsOutput += "<song>\n";
            }
            songsOutput += "</songs>";


            string usersOutput = "";
            usersOutput += "<users>\n";
            foreach (var item in PlayLs)
            {
                usersOutput += "<user>\n";
                usersOutput += "<id>" + item.Id + "</id>\n";
                usersOutput += "<name>" + item.Name + "</name>\n";
                usersOutput += "</users>\n";
            }
            usersOutput += "</users>";

            File.WriteAllText(@"Songs.xml", songsOutput);
            File.WriteAllText(@"Users.xml", usersOutput);
        }
    }
}

